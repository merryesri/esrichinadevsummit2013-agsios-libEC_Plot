//
//  IPointCountFixedPlot.h
//  PlotSample
//
//  Created by iphone4 on 11-6-22.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol IPointCountFixedPlot < NSObject >

- (int)getFixedPointCount;


@end

